<!DOCTYPE html>
<html>
<head>
<title> CS-251A: LET'S BUILD STUFF! EVENT REGISTRATION </title>
<center>
CS-251A: LET'S BUILD STUFF! EVENT REGISTRATION
</center><br>
<br>
<br>
<br>
</head>
<body>



<center>
 
   
    <form name="myForm" action="/bank.php" onsubmit="return validateForm()"   
          method="POST" enctype="multipart/form-data"> 
    <input type="hidden" name="action" value="submit"> 
   
    LOGIN ID:<br> 
    <input name="id" type="text" value="" size="30"/><br> 

    PASSWORD:<br> 
    <input name="pass" type="password" value="" size="30"/><br> 
       
     
    <br>
    <br>  
      
    <input type="submit" value="Submit"/> 
    <input type="reset" value="Reset"/>
    </form> 
    
    <br>
    <br>
    <br>
    
</center>


<br>
<br>
<center>
<p><br> Go back to Registration Page:<br> <a href="/form.php" title="Some say it's a search engine">Another Registration</a></p>
</center>
 



</body>
</html>
